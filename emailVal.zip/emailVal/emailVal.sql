UPDATE users
SET birthday = '1990-01-01'
WHERE id = 1;

SELECT * FROM users;